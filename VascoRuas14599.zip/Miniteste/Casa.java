/* javac Casa.java
java Casa */

public class Casa {
    private String TipoCasa = "Quinta";    
    private int NumAndares = 3;    
    private int NumQuartos = 4;    
    private int CasasDeBanho = 6;    
    private String AreaBruta = "1200 metros quadrados"; 
    private String AreaUtil = "600 metros quadrados";    
    
    public void setTipoCasa (String aux) {
        this.TipoCasa = aux;
    }

    public String getTipoCasa () {
        return this.TipoCasa;
    }

    public void setNumAndares (int num) {
        this.NumAndares = num;
    }

    public int getNumAndares () {
        return this.NumAndares;
    }

    public void setNumQuartos (int num) {
        this.NumQuartos = num;
    }

    public int getNumQuartos () {
        return this.NumQuartos;
    }

    public void setCasasDeBanho (int num) {
        this.CasasDeBanho = num;
    }

    public int getCasasDeBanho () {
        return this.CasasDeBanho;
    }

    public void setAreaBruta (String aux) {
        this.AreaBruta = aux;
    }

    public String getAreaBruta () {
        return this.AreaBruta;
    }

    public void setAreaUtil (String aux) {
        this.AreaUtil = aux;
    }

    public String getAreaUtil () {
        return this.AreaUtil;
    }

    public void informacao (String [] args) {
        System.out.println ("Tipo de casa: " + getTipoCasa());
        System.out.println ("Numero de andares: " + getNumAndares());
        System.out.println ("Numero de quartos: "+ getNumQuartos());
        System.out.println ("Casas de banho: " + getCasasDeBanho());
        System.out.println ("Area bruta: " + getAreaBruta());
        System.out.println ("Area util: "+ getAreaUtil());
    }
}