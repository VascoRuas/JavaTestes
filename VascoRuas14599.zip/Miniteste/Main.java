public class Main {
    public class Informacoes {
        System.out.println ("Informaçao: " + informacao());
    } 
}
