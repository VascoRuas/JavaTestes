public class Mota extends Veiculo{
    private boolean pagaIUC ;
    private String suporteMalas  ;
    public boolean isPagaIUC() {
        return pagaIUC;
    }
    public void setPagaIUC(boolean pagaIUC) {
        this.pagaIUC = pagaIUC;
    }
    public String getSuporteMalas() {
        return suporteMalas;
    }
    public void setSuporteMalas(String suporteMalas) {
        this.suporteMalas = suporteMalas;
    }
    public Mota(String matricula, int dataDaMatricula, String marca, String modelo, int numeroRodas, String iuc,
            String tipoDeVeiculo, String combustivel, int kms, boolean pagaIUC, String suporteMalas) {
        this.pagaIUC = pagaIUC;
        this.suporteMalas = suporteMalas;
    }
    public Mota(boolean pagaIUC, String suporteMalas) {
        this.pagaIUC = pagaIUC;
        this.suporteMalas = suporteMalas;
        setSuporteMalas ("Suporte de Mala Traseira");
    }
    
    public Mota() {
        super ();
        this.pagaIUC = false;
        this.suporteMalas = "";
        setPagaIUC (false);
    }

    public void getInfo() {
        System.out.println ("PagaIUC: ".toUpperCase() + pagaIUC + "\n_____________________________" + "\nSuporte de malas: ".toUpperCase() + suporteMalas.toUpperCase());
    }
    @Override
    public String toString() {
        return "Mota [pagaIUC=" + pagaIUC + ", suporteMalas=" + suporteMalas + "]";
    }

    
}
