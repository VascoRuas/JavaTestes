import java.util.Calendar;

public class Veiculo{
    private String matricula;
    private int dataDaMatricula;
    private String marca;
    private String modelo;
    private int numeroRodas;
    private String iuc;
    private String tipoDeVeiculo;
    private String combustivel;  
    private int kms ;
    public String getMatricula() {
        return matricula;
    }
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    public int getDataDaMatricula() {
        return dataDaMatricula;
    }
    public void setDataDaMatricula(int dataDaMatricula) {
        this.dataDaMatricula = dataDaMatricula;
    }
    public String getMarca() {
        return marca;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public String getModelo() {
        return modelo;
    }
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }
    public int getNumeroRodas() {
        return numeroRodas;
    }
    public void setNumeroRodas(int numeroRodas) {
        this.numeroRodas = numeroRodas;
    }
    public String getIuc() {
        return iuc;
    }
    public void setIuc(String iuc) {
        this.iuc = iuc;
    }
    public String getTipoDeVeiculo() {
        return tipoDeVeiculo;
    }
    public void setTipoDeVeiculo(String tipoDeVeiculo) {
        this.tipoDeVeiculo = tipoDeVeiculo;
    }
    public String getCombustivel() {
        return combustivel;
    }
    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }
    public int getKms() {
        return kms;
    }
    public void setKms(int kms) {
        this.kms = kms;
    }

    //getters e setters
    public Veiculo(String matricula, int dataDaMatricula, String marca, String modelo, int numeroRodas, String iuc,
            String tipoDeVeiculo, String combustivel, int kms) {
        this.matricula = matricula;
        this.dataDaMatricula = 0;
        this.marca = marca;
        this.modelo = modelo;
        this.numeroRodas = numeroRodas;
        this.iuc = iuc;
        this.tipoDeVeiculo = tipoDeVeiculo;
        this.combustivel = combustivel;
        this.kms = kms;
    }  

    public Veiculo() {
        this.matricula = "";
        this.dataDaMatricula = 0;
        this.marca = "";
        this.modelo = "";
        this.numeroRodas = 0;
        this.iuc = "";
        this.tipoDeVeiculo = "";
        this.combustivel = "";
        this.kms = 0;
    }
    //construtores
    @Override
    public String toString() {
        return "Veiculo [matricula=" + matricula + ", dataDaMatricula=" + dataDaMatricula + ", marca=" + marca
                + ", modelo=" + modelo + ", numeroRodas=" + numeroRodas + ", iuc=" + iuc + ", tipoDeVeiculo="
                + tipoDeVeiculo + ", combustivel=" + combustivel + ", kms=" + kms + "]";
    }  

    public int getIdadeVeiculo() {
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        return currentYear - dataDaMatricula;
    } // idade

    

    
}