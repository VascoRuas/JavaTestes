public class App {
    public static void main(String[] args) throws Exception {
        Carro Carro1 = new Carro (false,5);
        Carro Carro2 = new Carro (false,5);
        Mota Mota1 = new Mota (false,"");
        Mota Mota2 = new Mota (false,"");
        System.out.println(Mota2);
        Mota1.getInfo();
        Carro1.getIdadeVeiculo();
        Carro2.getIdadeVeiculo();

    }
    
}
