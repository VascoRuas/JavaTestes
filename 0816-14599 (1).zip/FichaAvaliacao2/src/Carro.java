public class Carro extends Veiculo{
    private boolean classico;
    private int numeroLugares;
    public boolean isClassico() {
        return classico;
    }
    public void setClassico(boolean classico) {
        this.classico = classico;
    }
    public int getNumeroLugares() {
        return numeroLugares;
    }
    public void setNumeroLugares(int numeroLugares) {
        this.numeroLugares = numeroLugares;
    }
    public Carro(boolean classico, int numeroLugares) {
        this.classico = classico;
        this.numeroLugares = numeroLugares;
        setClassico (true);
    }

    public Carro() {
        this.classico = classico;
        this.numeroLugares = numeroLugares;
        setNumeroLugares (7);
    }
    
    @Override
    public String toString() {
        return "Carro [classico=" + classico + ", numeroLugares=" + numeroLugares + "]";
    }

    public String getInfo() {
        return "Carro clássico: ".toUpperCase() + classico + "\n_____________________________" + "Numero de lugares: ".toUpperCase() + numeroLugares + "\n_____________________________";
    }

    
}