public class App {
    public static void main(String[] args) throws Exception {
        Aluno Aluno1 = new Aluno ("a1222","Jonas","Rato",2000,"1P");
        Aluno Aluno2 = new Aluno ("a1476","Angelo","Rapado",2000,"1P");
        Aluno Aluno3 = new Aluno ("a1567","Pedrocas","Animal",2000,"1P");
        Turma Turma1 = new Turma ("c132","Programação",2024,2025);
        Professor Professor1 = new Professor (14455,"Luis","Santos",1990,"Programação");

        System.out.println (Aluno1);
        System.out.println (Aluno2);
        System.out.println (Aluno3);
        System.out.println (Professor1);
        System.out.println (Turma1);
        Turma1.getInfoTurma();
        System.out.println("Idade do aluno1: " + Aluno1.getIdade() + "\n");
        System.out.println("Nome do Professor1: " + Professor1.getNomeCompleto() + "\n" );
    }
}
